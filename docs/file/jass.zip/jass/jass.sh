#!/bin/bash

java -classpath jass3new.jar jass3.gui.JassGui
